class Simple{  
    public static void main(String args[]){  
     System.out.println("Hello batch21 team");
      System.out.println("Hello batch16 and batch17 students and training practicing ");
    }  
}  
